class TreatmentsSlides{

  String _title;
  String _imgUrl;
  String _subTitle;
  String _buttonTitle;

  TreatmentsSlides(this._title,this._imgUrl,this._subTitle,this._buttonTitle);

  String get title=>_title;
  String get imgUrl=>_imgUrl;
  String get subTitle=>_subTitle;
  String get buttonTitle=>_buttonTitle;

}