---
name: 💥 Proposal
about: Propose a non-trivial change 
labels: "proposal"
---

## 💥 Proposal

(A clear and concise description of what the proposal is.)

### Have you read the *Contributing Guidelines on Pull Requests* ?

(Write your answer here.)

